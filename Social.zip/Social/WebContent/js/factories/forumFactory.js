app.factory('forumFactory', ['$http','$q','$rootScope',function($http,$q,$rootScope){
	var address = 'http://localhost:9089/rest/';
	var addressForForum = 'http://localhost:9089/rest/forum/add';
	var addressForGetAllForums= 'http://localhost:9089/rest/forum/getAll';
	var addressForGetForum= 'http://localhost:9089/rest/forum/getForum';
	var addressForDeleteForum= 'http://localhost:9089/rest/forum/deleteForum';
	var addressForUpdateForum= 'http://localhost:9089/rest/forum/updateForum';

	var self=this;
	return {
		registerForum:registerForum,
		fetchAllForums:fetchAllForums,
		fetchForum:fetchForum,
		deleteForum:deleteForum,
		updateForum:updateForum		
	};
	function registerForum(forum){
		var deferred = $q.defer();
		$http.post(addressForForum,forum).
		then(function(response){
			deferred.resolve(response.data);
		},function(errResponse){
			deferred.reject(errResponse);
		});
		alert("Forum Submitted " + forum.forumTitle);
		return deferred.promise;
	};
	
	function fetchAllForums(){
		//Create a deferred object
		var deferred = $q.defer();
		//var value = $rootScope.username+":"+$rootScope.password;
		//console.log(value);		
		$http.get(addressForGetAllForums)
		.then(function(response){
			deferred.resolve(response.data);
		},
		function(errResponse){
			console.error('Error fetching Forums');
			deferred.reject(errResponse);
		});
		return deferred.promise;	 
	};

	function fetchForum(forumId){		
		var deferred = $q.defer();		
		$http.get(addressForGetForum+"/"+forumId)
		.then(function(response){
			deferred.resolve(response.data);			
		},
		function(errResponse){
			console.error('Error fetching forums');
			deferred.reject(errResponse);
		});
		return deferred.promise;	 
	};
	function deleteForum(forumId){		
		var deferred = $q.defer();		
		$http.get(addressForDeleteForum+"/"+forumId)
		.then(function(response){
			deferred.resolve(response.data);			
		},
		function(errResponse){
			console.error('Error fetching forums');
			deferred.reject(errResponse);
		});
		return deferred.promise;	 
	};

	function updateForum(forum){
		var deferred = $q.defer();
		$http.post(addressForUpdateForum,forum). 
		then(function(response){
			deferred.resolve(response.data);
		},function(errResponse){
			deferred.reject(errResponse);
		});
		
		return deferred.promise;
	};

	
}]);