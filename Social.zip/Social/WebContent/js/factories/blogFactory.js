app.factory('blogFactory', ['$http','$q','$rootScope',function($http,$q,$rootScope){
	var address = 'http://localhost:9089/rest/';
	var addressForBlog = 'http://localhost:9089/rest/blog/add';
	var addressForGetAllBlogs= 'http://localhost:9089/rest/blog/getAll';
	var addressForGetBlog= 'http://localhost:9089/rest/blog/getBlog';
	var addressForDeleteBlog= 'http://localhost:9089/rest/blog/deleteBlog';
	var addressForUpdateBlog= 'http://localhost:9089/rest/blog/updateBlog';
	var self=this;
	return {
		registerBlog:registerBlog,
		fetchAllBlogs:fetchAllBlogs,
		fetchBlog:fetchBlog,
		deleteBlog:deleteBlog,
		updateBlog:updateBlog
		
	};
	function registerBlog(blog){
		var deferred = $q.defer();
		$http.post(addressForBlog,blog). 
		then(function(response){
			deferred.resolve(response.data);
		},function(errResponse){
			deferred.reject(errResponse);
		});
		alert("Blog Submitted " + blog.blogName);
		return deferred.promise;
	};
	
	function fetchAllBlogs(){
		//Create a deferred object
		var deferred = $q.defer();
		//var value = $rootScope.username+":"+$rootScope.password;
		//console.log(value);		
		$http.get(addressForGetAllBlogs)
		.then(function(response){
			deferred.resolve(response.data);
		},
		function(errResponse){
			console.error('Error fetching blogs');
			deferred.reject(errResponse);
		});
		return deferred.promise;	 
	};

	function fetchBlog(blogId){		
		var deferred = $q.defer();		
		$http.get(addressForGetBlog+"/"+blogId)
		.then(function(response){
			deferred.resolve(response.data);			
		},
		function(errResponse){
			console.error('Error fetching blogs');
			deferred.reject(errResponse);
		});
		return deferred.promise;	 
	};
	function deleteBlog(blogId){		
		var deferred = $q.defer();		
		$http.get(addressForDeleteBlog+"/"+blogId)
		.then(function(response){
			deferred.resolve(response.data);			
		},
		function(errResponse){
			console.error('Error fetching blogs');
			deferred.reject(errResponse);
		});
		return deferred.promise;	 
	};

	function updateBlog(blog){
		var deferred = $q.defer();
		$http.post(addressForUpdateBlog,blog). 
		then(function(response){
			deferred.resolve(response.data);
		},function(errResponse){
			deferred.reject(errResponse);
		});
		
		return deferred.promise;
	};
	
}]);