app.controller('loginController',['loginFactory','$rootScope','$location','$scope','$localStorage', function(loginFactory, $rootScope,$location,$scope,$localStorage){
	var self=this;
	self.user={email:'',name:'',role:'',contact:'',password:'',status:'', enabled:''};
	self.validateUser=function(){		
		loginFactory.validateUser(self.user);
		

	}	
}]);

