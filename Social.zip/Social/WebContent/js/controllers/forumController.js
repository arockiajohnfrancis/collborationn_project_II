app.controller('forumController',['forumFactory','$rootScope','$location','$scope','$localStorage','$route', function(forumFactory, $rootScope,$location,$scope,$localStorage,$route){
	var self=this;
	self.forum={forumId:'',forumTitle:'',forumDescription:'',creation:''};

	self.forums= [];	
	
	fetchAllForums();//function Call	

	self.registerForum=function(){
		/*self.user.status=true;
		self.user.enabled=true;*/
		forumFactory.registerForum(self.forum);
	}
	
	function fetchAllForums(){
		self.dataLoaded = false;
		forumFactory.fetchAllForums()
		.then(function(data){
			self.forums= data;
			self.dataLoaded = true;
			self.failed=false;
		},function(errResponse){
			console.error("Error fetching Forums");
			self.failed=true;
		});
	}
	self.fetchForum=function(forumId){
		console.log("Entering Controller");
		self.dataLoaded = false;
		forumFactory.fetchForum(forumId)
		.then(function(data){
			console.log("Returned")
			self.blog= data;		
			self.dataLoaded = true;
			self.failed=false;
			$rootScope.forum=data;
			$location.path("/viewForum")
			//forwardToBlog(self.blog);
			
		},function(errResponse){
			console.error("Error fetching blogs");
			self.failed=true;
		});
	}
	self.deleteForum=function(forumId){
		console.log("Entering Controller");
		self.dataLoaded = false;
		forumFactory.deleteForum(forumId)
		.then(function(){
			console.log("Returned")
			$route.reload();
			//forwardToBlog(self.blog);
			
		},function(errResponse){
			console.error("Error fetching blogs");
			self.failed=true;
		});
	}
	self.updateForum=function(forum){
		console.log("Entering Controller");
		self.dataLoaded = false;
		console.log(self.forum);
		self.forum=forum;
		forumFactory.updateForum(self.forum)
		.then(function(data){
			console.log("Returned")
			self.forums= data;
			self.dataLoaded = true;
			self.failed=false;		
			$rootScope.forum=data;
			$location.path("/listForum")
			//forwardToBlog(self.blog);
			
		},function(errResponse){
			console.error("Error fetching blogs");
			self.failed=true;
		});
	}

	
}]);