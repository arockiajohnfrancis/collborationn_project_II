app.controller('blogController',['blogFactory','$rootScope','$location','$scope','$localStorage','$route', function(blogFactory, $rootScope,$location,$scope,$localStorage,$route){
	var self=this;
	self.blog={blogId:'',blogName:'',userId:'',blogDescription:'',creation:''};
	self.blogs= [];	
	
	fetchAllBlogs();//function Call	

	self.registerBlog=function(){
		//self.user.status=true;
		//self.user.enabled=true;
		blogFactory.registerBlog(self.blog);
	}	
	
	function fetchAllBlogs(){
		self.dataLoaded = false;
		blogFactory.fetchAllBlogs()
		.then(function(data){
			self.blogs= data;
			self.dataLoaded = true;
			self.failed=false;
		},function(errResponse){
			console.error("Error fetching blogs");
			self.failed=true;
		});
	}
	self.fetchBlog=function(blogId){
		console.log("Entering Controller");
		self.dataLoaded = false;
		blogFactory.fetchBlog(blogId)
		.then(function(data){
			console.log("Returned")
			self.blog= data;		
			self.dataLoaded = true;
			self.failed=false;
			$rootScope.blog=data;
			$location.path("/viewBlog")
			//forwardToBlog(self.blog);
			
		},function(errResponse){
			console.error("Error fetching blogs");
			self.failed=true;
		});
	}
	self.deleteBlog=function(blogId){
		console.log("Entering Controller");
		self.dataLoaded = false;
		blogFactory.deleteBlog(blogId)
		.then(function(){
			console.log("Returned")
			$route.reload();
			//forwardToBlog(self.blog);
			
		},function(errResponse){
			console.error("Error fetching blogs");
			self.failed=true;
		});
	}
	self.updateBlog=function(blog){
		console.log("Entering Controller");
		self.dataLoaded = false;
		console.log(self.blog);
		self.blog=blog;
		blogFactory.updateBlog(self.blog)
		.then(function(data){
			console.log("Returned")
			self.blogs= data;
			self.dataLoaded = true;
			self.failed=false;		
			$rootScope.blog=data;
			$location.path("/listBlog")
			//forwardToBlog(self.blog);
			
		},function(errResponse){
			console.error("Error fetching blogs");
			self.failed=true;
		});
	}


	}]);