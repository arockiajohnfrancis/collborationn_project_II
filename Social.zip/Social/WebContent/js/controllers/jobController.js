app.controller('jobController',['jobFactory','$rootScope','$location','$scope','$localStorage', '$route',function(jobFactory, $rootScope,$location,$scope,$localStorage,$route){
	var self=this;
	self.job={jobId:'',jobTitle:'',jobpost:'',company:'',qualification:'',experience:'',location:'', salary:'', vacancies:'', field:'',creation:''};
	
	self.jobs= [];	
	
	fetchAllJobs();//function Call	
	//alert("loading");
	
	self.registerJob=function(){
		/*self.user.status=true;
		self.user.enabled=true;*/
		jobFactory.registerJob(self.job);
	}
	
	function fetchAllJobs(){
		self.dataLoaded = false;
		jobFactory.fetchAllJobs()
		.then(function(data){
			self.jobs= data;
			self.dataLoaded = true;
			self.failed=false;
		},function(errResponse){
			console.error("Error fetching job");
			self.failed=true;
		});
	}
	self.fetchJob=function(jobId){
		console.log("Entering Controller");
		self.dataLoaded = false;
		jobFactory.fetchJob(jobId)
		.then(function(data){
			console.log("Returned")
			self.job= data;		
			self.dataLoaded = true;
			self.failed=false;
			$rootScope.job=data;
			$location.path("/viewJob")
			//forwardTol(self.blog);
			
		},function(errResponse){
			console.error("Error fetching jobs");
			self.failed=true;
		});
	}
	self.deleteJob=function(jobId){
		console.log("Entering Controller");
		self.dataLoaded = false;
		jobFactory.deleteJob(jobId)
		.then(function(){
			console.log("Returned")
			$route.reload();
			//forwardToBlog(self.blog);
			
		},function(errResponse){
			console.error("Error fetching job");
			self.failed=true;
		});
	}
	
	
	self.updateJob=function(job){
		console.log("Entering Controller");
		self.dataLoaded = false;
		console.log(self.job);
		self.job=job;
		jobFactory.updateJob(self.job)
		.then(function(data){
			console.log("Returned")
			self.jobs= data;
			self.dataLoaded = true;
			self.failed=false;		
			$rootScope.job=data;
			$location.path("/listJob")
			//forwardToBlog(self.blog);
			
		},function(errResponse){
			console.error("Error fetching job");
			self.failed=true;
		});
	}

	
}]);