package com.niit.social.hiber.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.niit.social.hiber.dao.UserDao;
import com.niit.social.hiber.model.User;

@Repository
public class UserImpl implements UserDao {
	@Autowired
	private SessionFactory sessionFactory;

	public void save(User entity) {
		Session session=sessionFactory.openSession();
		session.getTransaction().begin();
		session.save(entity);
		session.getTransaction().commit();
		session.close();		
	}

	public void delete(String email) {
		Session session=sessionFactory.openSession();
		session.getTransaction().begin();
		session.delete(find(email));
		session.getTransaction().commit();
		session.close();
	}

	public void update(User entity) {
		Session session=sessionFactory.openSession();
		session.getTransaction().begin();
		session.update(entity);
		session.getTransaction().commit();
		session.close();
	}

	public User find(String email) {
		Session session=sessionFactory.openSession();
		session.beginTransaction();
		Criteria criteria=session.createCriteria(User.class);
		criteria.add(Restrictions.eq("email",email));
		List list=criteria.list();
		session.getTransaction().commit();
		session.close();
		if(!list.isEmpty()){
			return (User)list.get(0);
		}else{
			return null;
		}
	}

	public List<User> findAll() {
		Session session=sessionFactory.openSession();
		session.beginTransaction();
		Criteria criteria=session.createCriteria(User.class);		
		List<User> list=(List<User>) criteria.list();
		session.getTransaction().commit();
		session.close();
		if(!list.isEmpty()){
			return list;
		}else{
			return null;
		}
	}

}
