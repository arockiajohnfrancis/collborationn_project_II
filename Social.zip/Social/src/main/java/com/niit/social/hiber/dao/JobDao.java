package com.niit.social.hiber.dao;


import java.util.List;

import com.niit.social.hiber.model.Jobs;

public interface JobDao {

void save(Jobs job);
	
	void delete(int jobId);
	void update(Jobs job);
	Jobs find(int jobId);
	List<Jobs> findAll();

}
