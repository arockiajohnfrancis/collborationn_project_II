package com.niit.social.hiber.model;

import java.util.Date;

import javax.persistence.Column;

//import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.springframework.stereotype.Component;

@Entity(name="Forum")
@Component
public class Forum {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int forumId;
	@Column(name="title")
	private String forumTitle;
	@Column(name="description")
	private String forumDescription;
	@Column(name="creation")
	private Date creation;
	
	
	public int getForumId() {
		return forumId;
	}
	public void setForumId(int forumId) {
		this.forumId = forumId;
	}
	public String getForumTitle() {
		return forumTitle;
	}
	public void setForumTitle(String forumTitle) {
		this.forumTitle = forumTitle;
	}
	public String getForumDescription() {
		return forumDescription;
	}
	public void setForumDescription(String forumDescription) {
		this.forumDescription = forumDescription;
	}
	public Date getCreation() {
		return creation;
	}
	public void setCreation(Date creation) {
		this.creation = creation;
	}
}



