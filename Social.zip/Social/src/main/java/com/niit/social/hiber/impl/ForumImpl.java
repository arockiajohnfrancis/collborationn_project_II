package com.niit.social.hiber.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.niit.social.hiber.dao.ForumDao;
import com.niit.social.hiber.model.Forum;

@Repository
public class ForumImpl implements ForumDao{
	
	@Autowired
	private SessionFactory sessionFactory;
	
	public void save(Forum forum) {
		// TODO Auto-generated method stub
		
		Session session=sessionFactory.openSession();
		session.getTransaction().begin();
		session.save(forum);
		session.getTransaction().commit();
		session.close();		
		
	}

	public void delete(int forumId) {
		// TODO Auto-generated method stub
		Session session=sessionFactory.openSession();
		session.getTransaction().begin();
		session.delete(find(forumId));
		session.getTransaction().commit();
		session.close();

		
	}

	public void update(Forum forum) {
		Session session=sessionFactory.openSession();
		session.getTransaction().begin();
		session.update(forum);
		session.getTransaction().commit();
		session.close();
	
		// TODO Auto-generated method stub
		
	}

	public Forum find(int forumId) {
		Session session=sessionFactory.openSession();
		session.beginTransaction();
		Criteria criteria=session.createCriteria(Forum.class);
		criteria.add(Restrictions.eq("id", new Integer(forumId)));
		List list=criteria.list();
		session.getTransaction().commit();
		session.close();
		if(!list.isEmpty()){
			return (Forum)list.get(0);
		}else{
			return null;
		}
		
		// TODO Auto-generated method stub
	}

	public List<Forum> findAll() {
		Session session=sessionFactory.openSession();
		session.beginTransaction();
		Criteria criteria=session.createCriteria(Forum.class);		
		List<Forum> list=(List<Forum>) criteria.list();
		session.getTransaction().commit();
		session.close();
		if(!list.isEmpty()){
			return list;
		}else{
			return null;
		}


		
	}

		// TODO Auto-generated method stub
	
	}



