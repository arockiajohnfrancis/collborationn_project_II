package com.niit.social.hiber.config;




import java.util.Properties;

import javax.sql.DataSource;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate4.LocalSessionFactoryBuilder;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.niit.social.hiber.model.Blog;
import com.niit.social.hiber.model.Forum;
import com.niit.social.hiber.model.Jobs;
import com.niit.social.hiber.model.User;

@Configuration
@ComponentScan({"com.niit.social"})
@EnableTransactionManagement
public class HibernateConfig{
	   @Autowired
	    @Bean(name ="dataSource")
	    public DataSource dataSource() {

	        DriverManagerDataSource ds = new DriverManagerDataSource();
	        ds.setDriverClassName("org.h2.Driver");
	        ds.setUrl("jdbc:h2:tcp://localhost/~/socials");
	        ds.setUsername("sa");
	        ds.setPassword("");
	        return ds;
	    }
	   @Autowired
	    @Bean
	    public SessionFactory sessionFactory(DataSource dataSource) {
	        LocalSessionFactoryBuilder builder = new LocalSessionFactoryBuilder(dataSource);
	        builder.addProperties(getHibernateProperties());
	        builder.scanPackages("com.niit.social.hiber");
	        builder.addAnnotatedClass(User.class);
	        builder.addAnnotatedClass(Blog.class);
	        builder.addAnnotatedClass(Forum.class);
	        builder.addAnnotatedClass(Jobs.class);
	        
	        return builder.buildSessionFactory();
	    }	   

	    private Properties getHibernateProperties() {
	        Properties prop = new Properties();
	        prop.put("hibernate.show_sql", "true");
	        prop.put("hibernate.dialect", "org.hibernate.dialect.H2Dialect");
	        prop.put("hibernate.format_sql", "true");
	        prop.put("hibernate.hbm2ddl.auto", "update");
	        return prop;
	    }



}
