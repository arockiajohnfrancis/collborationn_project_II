package com.niit.social.hiber.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.springframework.stereotype.Component;

@Entity(name="Jobs")
@Component
public class Jobs {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int jobId;
	@Column(name="title")
	private String jobTitle ;
	@Column(name="post")
	private String jobpost;
	@Column(name="company")
	private String company;
	@Column(name="qualification")
	private String qualification;
	@Column(name="experience")
	private String experience;
	@Column(name="location")
	private String location;
	@Column(name="salary")
	private String salary;
	@Column(name="vacancies")
	private String vacancies;
	@Column(name="field")
	private String field;
	@Column(name="creation")
	private Date creation;
	
	
	public int getJobId() {
		return jobId;
	}
	public void setJobId(int jobId) {
		this.jobId = jobId;
	}
	public String getJobTitle() {
		return jobTitle;
	}
	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}
	public String getJobpost() {
		return jobpost;
	}
	public void setJobpost(String jobpost) {
		this.jobpost = jobpost;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public String getQualification() {
		return qualification;
	}
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	public String getExperience() {
		return experience;
	}
	public void setExperience(String experience) {
		this.experience = experience;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getSalary() {
		return salary;
	}
	public void setSalary(String salary) {
		this.salary = salary;
	}
	public String getVacancies() {
		return vacancies;
	}
	public void setVacancies(String vacancies) {
		this.vacancies = vacancies;
	}
	public String getField() {
		return field;
	}
	public void setField(String field) {
		this.field = field;
	}

	public Date getCreation() {
		return creation;
	}
	public void setCreation(Date creation) {
		this.creation = creation;
	}
}
